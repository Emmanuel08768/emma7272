import React from "react";

function Services() {
  return <h2>Services Section</h2>;
}

export default Services;
