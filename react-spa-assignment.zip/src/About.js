import React from "react";

function About() {
  return <h2>About Section</h2>;
}

export default About;
