import React from "react";

function Banner() {
  return <h2>Banner Section</h2>;
}

export default Banner;
